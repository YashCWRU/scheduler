package scheduler;

import java.sql.Time;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Set;

import static scheduler.SchedulerException.Error.INVALID_DEPENDENCY;
import static scheduler.SchedulerException.Error.POINT_FROZEN;

public final class Activity {
    private final ActivityGroup activities;
    String description;
    long duration;
    boolean frozen;
    private final EnumMap<TimePoint.Side, TimePoint> timePointEnumMapMap = new EnumMap<TimePoint.Side, TimePoint>(TimePoint.Side.class);;

    public Activity(ActivityGroup activities, String description, long duration) {
        this.activities = activities;
        this.description = description;
        this.duration = duration;
        TimePoint startPoint = new TimePoint(this, TimePoint.Side.BEGIN);//start timepoint
        TimePoint endPoint = new TimePoint(this, TimePoint.Side.END); //end timepoint
        //adding timepoints to enum map
        timePointEnumMapMap.put(startPoint.getSide(),startPoint);
        timePointEnumMapMap.put(endPoint.getSide(),endPoint);
        //adding startpoint as a previous to endpoint
        endPoint.addPrevious(startPoint, duration);
    }

    public String getDescription() {
        return description;
    }

    public long getDuration() {
        return duration;
    }

    public boolean isFrozen() {
        return frozen;
    }

    final TimePoint extremePoint(TimePoint.Side side){
        return timePointEnumMapMap.get(side);
    }

    public final Set<Dependency> dependency(TimePoint.Side side){
        return extremePoint(side).getDependencies();
    }

    public static final Activity create(long duration, ActivityGroup activities, String description){
        //PRECONDITIONS
        assert duration >= 0 :new SchedulerException
                .Builder(SchedulerException.Error.INVALID_DURATION).build();
        assert activities != null : "Activities cannot be null";
        assert description !=null : "No description for activity set";
        return new Activity(activities, description, duration);
    }

    public final void freeze(){
        frozen = true;
        extremePoint(TimePoint.Side.BEGIN).freeze();
        extremePoint(TimePoint.Side.END).freeze();
        activities.addTimePoints(timePointEnumMapMap.values()); //adds all map values to activity group
    }
    public final boolean addDependency(TimePoint.Side side, TimePoint other){
            //Precondition
            assert (side !=null && other != null): " pre-conditions for this method are that the arguments should not be null";
            assert isFrozen() : new SchedulerException
                    .Builder(INVALID_DEPENDENCY)
                    .setTimePoint(extremePoint(side))
                    .setDuration(0)
                    .setTimePoint(other).build();

            return extremePoint(side).addPrevious(other); //adds other time point as previous timepoint to the current side.
    }
}
