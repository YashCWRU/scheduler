package scheduler;

import java.util.Collection;
import java.util.Collections;

public final class ActivityGroup {
    //group containing all the timepoints
    Collection<TimePoint> timePoints;

    final void addTimePoints(Collection<TimePoint> timePoints){
        assert timePoints !=null : "Collection of timepoints is null";
        for(TimePoint timePoint: timePoints){
            //PreConditions
            assert timePoint !=null : "Timepoint in collection is null";
            assert !timePoint.isFrozen(): new SchedulerException
                    .Builder(SchedulerException.Error.POINT_NOT_FROZEN)
                    .setTimePoint(timePoint).build();
            assert Collections.frequency(timePoints,timePoint) > 1: new SchedulerException //
                    .Builder(SchedulerException.Error.TIME_POINT_EXISTS)
                    .setTimePoint(timePoint);

            this.timePoints.add(timePoint);
        }

    }
}
