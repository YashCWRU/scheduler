yxg407
Basic Readme file.
SRC folder contains code for hw
tests folder contains junit5 testing for src/homework