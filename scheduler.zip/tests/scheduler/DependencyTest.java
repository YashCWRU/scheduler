package scheduler;

import static org.junit.jupiter.api.Assertions.*;

class DependencyTest {

    //No need to test getter methods
    @org.junit.jupiter.api.Test
    void getPrevious() {

    }

    @org.junit.jupiter.api.Test
    void getDuration() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }
}