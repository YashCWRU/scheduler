package scheduler;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ActivityTest {

    @Test
    void create() {
        assertThrows(AssertionError.class, () ->{Activity.create(1, new ActivityGroup(),null);} );
        assertThrows(AssertionError.class, () ->{Activity.create(1,null,"hi");} );
        assertThrows(AssertionError.class, () ->{Activity.create(-2,new ActivityGroup(),"hi");} );
    }

    @Test
    void freeze() {
    }

    @Test
    void addDependency() {
    }
}