package scheduler;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SchedulerExceptionTest {

    @Test
    void getError() {
    }

    @Test
    void getTimePoint() {
    }

    @Test
    void getOtherTimePoint() {
    }

    @Test
    void getDuration() {
    }

    @Test
    void testToString() {
    }
}